"""
predict.py
----------
Loads the trained HDI classification model and predicts the HDI
category for one or more countries given their development indicators.

Usage examples:

    # Run built-in demo scenarios (Very High / Medium / Low)
    python src/predict.py --demo

    # Predict a single custom country
    python src/predict.py --life_expectancy 78 --mean_years_schooling 12 \\
        --expected_years_schooling 16 --gni_per_capita 35000
"""

import os
import argparse
import joblib
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "model", "hdi_model.joblib")
ENCODER_PATH = os.path.join(BASE_DIR, "model", "label_encoder.joblib")

FEATURES = [
    "life_expectancy",
    "mean_years_schooling",
    "expected_years_schooling",
    "gni_per_capita",
]

# The three scenarios described in the project brief
DEMO_SCENARIOS = {
    "Scenario 1 - Very High Human Development (developed nation)": {
        "life_expectancy": 82.0,
        "mean_years_schooling": 13.0,
        "expected_years_schooling": 17.0,
        "gni_per_capita": 55000,
    },
    "Scenario 2 - Development Gaps (emerging economy)": {
        "life_expectancy": 68.0,
        "mean_years_schooling": 7.0,
        "expected_years_schooling": 11.0,
        "gni_per_capita": 8000,
    },
    "Scenario 3 - Development Intervention Needed (low HDI)": {
        "life_expectancy": 52.0,
        "mean_years_schooling": 3.0,
        "expected_years_schooling": 6.0,
        "gni_per_capita": 1500,
    },
}


def load_model():
    if not (os.path.exists(MODEL_PATH) and os.path.exists(ENCODER_PATH)):
        raise FileNotFoundError(
            "Trained model not found. Run src/train_model.py first."
        )
    model = joblib.load(MODEL_PATH)
    label_encoder = joblib.load(ENCODER_PATH)
    return model, label_encoder


def predict_one(model, label_encoder, indicators: dict):
    X = pd.DataFrame([indicators], columns=FEATURES)
    pred_encoded = model.predict(X)[0]
    proba = model.predict_proba(X)[0]
    category = label_encoder.inverse_transform([pred_encoded])[0]
    confidence = max(proba)
    return category, confidence


def run_demo():
    model, label_encoder = load_model()
    for name, indicators in DEMO_SCENARIOS.items():
        category, confidence = predict_one(model, label_encoder, indicators)
        print(f"\n{name}")
        print(f"  Inputs: {indicators}")
        print(f"  Predicted HDI category: {category}  (confidence: {confidence:.2%})")


def main():
    parser = argparse.ArgumentParser(description="Predict HDI category for a country.")
    parser.add_argument("--demo", action="store_true", help="Run the 3 built-in demo scenarios")
    parser.add_argument("--life_expectancy", type=float)
    parser.add_argument("--mean_years_schooling", type=float)
    parser.add_argument("--expected_years_schooling", type=float)
    parser.add_argument("--gni_per_capita", type=float)
    args = parser.parse_args()

    if args.demo or not any(
        [
            args.life_expectancy,
            args.mean_years_schooling,
            args.expected_years_schooling,
            args.gni_per_capita,
        ]
    ):
        run_demo()
        return

    missing = [
        f for f in FEATURES if getattr(args, f) is None
    ]
    if missing:
        raise SystemExit(f"Missing required arguments: {missing}")

    model, label_encoder = load_model()
    indicators = {f: getattr(args, f) for f in FEATURES}
    category, confidence = predict_one(model, label_encoder, indicators)
    print(f"Inputs: {indicators}")
    print(f"Predicted HDI category: {category}  (confidence: {confidence:.2%})")


if __name__ == "__main__":
    main()
