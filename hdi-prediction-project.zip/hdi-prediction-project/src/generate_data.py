"""
generate_data.py
-----------------
Generates a synthetic (but realistic) dataset of country-level Human
Development Index (HDI) indicators for training/testing the HDI
classification model.

Indicators used (aligned with UNDP's HDI methodology):
    - life_expectancy        : Life expectancy at birth (years)
    - mean_years_schooling   : Mean years of schooling (years)
    - expected_years_schooling: Expected years of schooling (years)
    - gni_per_capita         : Gross National Income per capita, PPP (USD)

Target:
    - hdi_category : One of "Low", "Medium", "High", "Very High"

Run:
    python src/generate_data.py
Produces:
    data/hdi_sample_data.csv
"""

import numpy as np
import pandas as pd
import os

RANDOM_SEED = 42
N_SAMPLES = 800

CATEGORY_RANGES = {
    "Low": {
        "life_expectancy": (45, 60),
        "mean_years_schooling": (1, 5),
        "expected_years_schooling": (4, 9),
        "gni_per_capita": (500, 4000),
    },
    "Medium": {
        "life_expectancy": (60, 70),
        "mean_years_schooling": (5, 8),
        "expected_years_schooling": (9, 12),
        "gni_per_capita": (4000, 12000),
    },
    "High": {
        "life_expectancy": (70, 77),
        "mean_years_schooling": (8, 11),
        "expected_years_schooling": (12, 15),
        "gni_per_capita": (12000, 28000),
    },
    "Very High": {
        "life_expectancy": (77, 85),
        "mean_years_schooling": (11, 15),
        "expected_years_schooling": (15, 19),
        "gni_per_capita": (28000, 80000),
    },
}


def generate_dataset(n_samples=N_SAMPLES, seed=RANDOM_SEED):
    rng = np.random.default_rng(seed)
    categories = list(CATEGORY_RANGES.keys())
    rows = []

    samples_per_category = n_samples // len(categories)

    for category in categories:
        ranges = CATEGORY_RANGES[category]
        for _ in range(samples_per_category):
            row = {
                "life_expectancy": round(rng.uniform(*ranges["life_expectancy"]), 1),
                "mean_years_schooling": round(rng.uniform(*ranges["mean_years_schooling"]), 1),
                "expected_years_schooling": round(rng.uniform(*ranges["expected_years_schooling"]), 1),
                "gni_per_capita": round(rng.uniform(*ranges["gni_per_capita"]), 2),
                "hdi_category": category,
            }
            rows.append(row)

    df = pd.DataFrame(rows)
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)  # shuffle
    return df


if __name__ == "__main__":
    df = generate_dataset()
    out_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "hdi_sample_data.csv")
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} rows -> {out_path}")
    print(df["hdi_category"].value_counts())
