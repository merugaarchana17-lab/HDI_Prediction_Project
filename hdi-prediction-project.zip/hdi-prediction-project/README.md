# Human Development Index (HDI) Prediction

A machine learning project that predicts a country's **Human Development
Index (HDI) category** — *Low*, *Medium*, *High*, or *Very High* — from
its core development indicators:

- **Life expectancy at birth** (years)
- **Mean years of schooling** (years)
- **Expected years of schooling** (years)
- **GNI per capita, PPP** (USD)

The HDI, developed by the UNDP, shifts the focus of development away from
GDP/economic growth alone and toward *people and their capabilities* —
health, education, and living standards combined.

## Project Scenarios

| Scenario | Description | Example Outcome |
|---|---|---|
| **1. Very High Human Development** | High life expectancy, strong schooling, high GNI per capita | Model predicts **Very High** HDI |
| **2. Development Gaps in Emerging Economies** | Moderate values across all indicators | Model predicts **Medium** HDI, flags improvement areas |
| **3. Development Intervention Needed** | Low life expectancy, limited education, low GNI | Model predicts **Low** HDI, highlights challenges |

## Project Structure

```
hdi-prediction-project/
├── app.py                     # Streamlit interactive web app
├── requirements.txt           # Python dependencies
├── data/
│   └── hdi_sample_data.csv    # Synthetic training dataset (generated)
├── model/
│   ├── hdi_model.joblib       # Trained model pipeline (generated)
│   └── label_encoder.joblib   # Label encoder (generated)
├── src/
│   ├── generate_data.py       # Creates the synthetic dataset
│   ├── train_model.py         # Trains & evaluates the classifier
│   └── predict.py             # CLI predictions + demo scenarios
└── README.md
```

## Setup

```bash
# 1. Clone the repo
git clone <your-repo-url>
cd hdi-prediction-project

# 2. Create a virtual environment (optional but recommended)
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt
```

## Usage

### 1. Generate the dataset
```bash
python src/generate_data.py
```

### 2. Train the model
```bash
python src/train_model.py
```
This prints accuracy, a classification report, and a confusion matrix,
then saves the trained pipeline to `model/hdi_model.joblib`.

### 3. Run predictions

Run the three built-in demo scenarios from the project brief:
```bash
python src/predict.py --demo
```

Or predict a custom country:
```bash
python src/predict.py \
    --life_expectancy 78 \
    --mean_years_schooling 12 \
    --expected_years_schooling 16 \
    --gni_per_capita 35000
```

### 4. (Optional) Launch the interactive web app
```bash
streamlit run app.py
```

## Model

- **Algorithm:** Random Forest Classifier (scikit-learn)
- **Pipeline:** `StandardScaler` → `RandomForestClassifier`
- **Features:** life expectancy, mean years of schooling, expected years
  of schooling, GNI per capita
- **Target:** HDI category (Low / Medium / High / Very High)

> **Note:** The bundled dataset (`data/hdi_sample_data.csv`) is
> synthetically generated to reflect realistic HDI value ranges per
> category, since real-world UNDP HDI data may be subject to licensing.
> To use real data, replace `data/hdi_sample_data.csv` with an official
> dataset (e.g., from the [UNDP Human Development Reports](https://hdr.undp.org/data-center))
> using the same column names, then re-run `src/train_model.py`.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: HDI prediction project"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

## License

This project is provided under the MIT License. See `LICENSE` for details.
