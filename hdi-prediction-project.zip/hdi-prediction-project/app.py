"""
app.py
------
Simple Streamlit web app for the HDI Prediction project.

Run:
    streamlit run app.py

Lets a user (e.g., a policymaker or researcher) enter a country's
indicators and get a predicted HDI category (Low / Medium / High /
Very High), matching Scenarios 1-3 from the project brief.
"""

import os
import joblib
import pandas as pd
import streamlit as st

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "hdi_model.joblib")
ENCODER_PATH = os.path.join(BASE_DIR, "model", "label_encoder.joblib")

FEATURES = [
    "life_expectancy",
    "mean_years_schooling",
    "expected_years_schooling",
    "gni_per_capita",
]


@st.cache_resource
def load_model():
    model = joblib.load(MODEL_PATH)
    label_encoder = joblib.load(ENCODER_PATH)
    return model, label_encoder


def main():
    st.set_page_config(page_title="HDI Predictor", page_icon="🌍")
    st.title("🌍 Human Development Index (HDI) Predictor")
    st.write(
        "Enter a country's indicators below to predict its HDI category: "
        "**Low**, **Medium**, **High**, or **Very High**."
    )

    if not (os.path.exists(MODEL_PATH) and os.path.exists(ENCODER_PATH)):
        st.error(
            "Model not found. Please run `python src/generate_data.py` "
            "and `python src/train_model.py` first."
        )
        return

    model, label_encoder = load_model()

    col1, col2 = st.columns(2)
    with col1:
        life_expectancy = st.slider("Life expectancy at birth (years)", 40.0, 90.0, 70.0)
        mean_years_schooling = st.slider("Mean years of schooling", 0.0, 16.0, 8.0)
    with col2:
        expected_years_schooling = st.slider("Expected years of schooling", 0.0, 20.0, 12.0)
        gni_per_capita = st.number_input("GNI per capita, PPP (USD)", min_value=0, value=15000, step=500)

    if st.button("Predict HDI Category", type="primary"):
        X = pd.DataFrame(
            [[life_expectancy, mean_years_schooling, expected_years_schooling, gni_per_capita]],
            columns=FEATURES,
        )
        pred_encoded = model.predict(X)[0]
        proba = model.predict_proba(X)[0]
        category = label_encoder.inverse_transform([pred_encoded])[0]
        confidence = max(proba)

        st.success(f"Predicted HDI Category: **{category}**")
        st.metric("Confidence", f"{confidence:.1%}")

        st.subheader("Class probabilities")
        proba_df = pd.DataFrame(
            {"HDI Category": label_encoder.classes_, "Probability": proba}
        ).sort_values("Probability", ascending=False)
        st.bar_chart(proba_df.set_index("HDI Category"))

    st.divider()
    st.caption(
        "Model: RandomForestClassifier trained on synthetic data modeled after "
        "UNDP HDI methodology (life expectancy, education, GNI per capita)."
    )


if __name__ == "__main__":
    main()
